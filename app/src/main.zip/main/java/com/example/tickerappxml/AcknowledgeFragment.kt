package com.example.tickerappxml

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import com.example.tickerappxml.databinding.FragmentAcknowledgeBinding
import models.TransactionDetails


class AcknowledgeFragment(
    context: Context,
    private val item: TransactionDetails
): Dialog(context) {

    private lateinit var binding: FragmentAcknowledgeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentAcknowledgeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.acknowledgeInfo.text = "You have successfully bought ${item.quantity} shares of ${item.ticker}"
        binding.acknowledgeDone.setOnClickListener {
            dismiss()
        }
    }



}