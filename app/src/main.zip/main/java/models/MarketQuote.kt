package models

data class MarketQuote(
    val marketChange: Double,
    val marketValue: Double
)