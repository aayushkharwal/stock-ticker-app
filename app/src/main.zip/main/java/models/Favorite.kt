package models

data class Favorite(
    val acknowledged: Boolean,
//    val insertedId: String,
    val status: String
)
