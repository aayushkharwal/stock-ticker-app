package models

data class Watchlist (
    val name: String,
    val ticker: String,
    val c: Double,
    val d: Double,
    val dp: Double
)