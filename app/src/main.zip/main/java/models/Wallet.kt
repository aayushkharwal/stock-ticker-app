package models

data class Wallet(
    val balance: Double
)
